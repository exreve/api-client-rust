# PrivateBalancesGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**free** | **std::collections::HashMap<String, String>** |  | 
**locked** | **std::collections::HashMap<String, String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


