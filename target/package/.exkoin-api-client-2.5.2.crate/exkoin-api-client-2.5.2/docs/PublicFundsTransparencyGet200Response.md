# PublicFundsTransparencyGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **f64** |  | 
**funds** | [**std::collections::HashMap<String, std::collections::HashMap<String, models::PublicFundsTransparencyGet200ResponseFundsValueValue>>**](std::collections::HashMap.md) |  | 
**stats** | [**std::collections::HashMap<String, models::PublicFundsTransparencyGet200ResponseStatsValue>**](_public_funds_transparency_get_200_response_stats_value.md) |  | 
**addresses_labels** | **std::collections::HashMap<String, String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


