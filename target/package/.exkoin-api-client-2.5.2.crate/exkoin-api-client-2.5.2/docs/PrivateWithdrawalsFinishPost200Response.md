# PrivateWithdrawalsFinishPost200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**currency** | **String** |  | 
**amount** | **String** |  | 
**user_fee** | **String** |  | 
**message** | **String** |  | 
**address** | **String** |  | 
**from_address** | **String** |  | 
**network** | **String** |  | 
**memo** | Option<**String**> |  | [optional]
**txid** | Option<**String**> |  | [optional]
**status** | **String** |  | 
**timestamp** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


