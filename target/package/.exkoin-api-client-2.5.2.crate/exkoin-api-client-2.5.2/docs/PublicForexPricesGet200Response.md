# PublicForexPricesGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**prices_usd** | **std::collections::HashMap<String, f64>** |  | 
**symb_to_name** | **std::collections::HashMap<String, String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


