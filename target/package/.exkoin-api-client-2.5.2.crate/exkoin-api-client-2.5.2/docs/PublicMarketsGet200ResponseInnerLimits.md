# PublicMarketsGet200ResponseInnerLimits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price** | [**models::PublicMarketsGet200ResponseInnerLimitsPrice**](_public_markets_get_200_response_inner_limits_price.md) |  | 
**amount** | [**models::PublicMarketsGet200ResponseInnerLimitsPrice**](_public_markets_get_200_response_inner_limits_price.md) |  | 
**cost** | [**models::PublicMarketsGet200ResponseInnerLimitsPrice**](_public_markets_get_200_response_inner_limits_price.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


