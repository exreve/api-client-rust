# PublicExkConfigGet200ResponseRoutesValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**weight** | **f64** |  | 
**description** | **String** |  | 
**free_amount** | **f64** |  | 
**locked_amount** | **f64** |  | 
**logs** | [**Vec<models::PublicExkConfigGet200ResponseRoutesValueLogsInner>**](_public_exk_config_get_200_response_routes_value_logs_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


