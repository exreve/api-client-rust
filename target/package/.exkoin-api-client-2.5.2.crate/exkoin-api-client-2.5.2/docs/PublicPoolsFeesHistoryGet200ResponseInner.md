# PublicPoolsFeesHistoryGet200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **f64** |  | 
**fees** | [**models::PublicPoolsGet200ResponseInnerEarned24h**](_public_pools_get_200_response_inner_earned_24h.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


