# PrivatePoolTasksGet200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**pool_id** | **String** |  | 
**r#type** | **String** |  | 
**status** | **String** |  | 
**created_at** | **f64** |  | 
**updated_at** | **f64** |  | 
**spent** | [**Vec<models::PrivatePoolTasksGet200ResponseInnerSpentInner>**](_private_pool_tasks_get_200_response_inner_spent_inner.md) |  | 
**got** | [**Vec<models::PrivatePoolTasksGet200ResponseInnerSpentInner>**](_private_pool_tasks_get_200_response_inner_spent_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


