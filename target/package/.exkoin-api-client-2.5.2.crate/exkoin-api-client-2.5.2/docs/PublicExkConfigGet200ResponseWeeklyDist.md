# PublicExkConfigGet200ResponseWeeklyDist

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cycle_id** | **f64** |  | 
**timestamp_to_next_dist** | **f64** |  | 
**total_points** | **f64** |  | 
**points_for** | **std::collections::HashMap<String, f64>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


