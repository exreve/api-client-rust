# PublicMarketsGet200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**base** | **String** |  | 
**quote** | **String** |  | 
**active** | Option<[**serde_json::Value**](.md)> |  | [optional]
**precision** | [**models::PublicMarketsGet200ResponseInnerPrecision**](_public_markets_get_200_response_inner_precision.md) |  | 
**limits** | [**models::PublicMarketsGet200ResponseInnerLimits**](_public_markets_get_200_response_inner_limits.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


