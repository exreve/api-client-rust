# PublicOhlcvGet200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**time** | **f64** |  | 
**open** | **String** |  | 
**high** | **String** |  | 
**low** | **String** |  | 
**close** | **String** |  | 
**volume** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


