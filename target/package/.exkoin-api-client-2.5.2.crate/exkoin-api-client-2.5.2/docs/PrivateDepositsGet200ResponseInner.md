# PrivateDepositsGet200ResponseInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**currency** | **String** |  | 
**amount** | **String** |  | 
**fee** | **String** |  | 
**address_to** | Option<**String**> |  | [optional]
**address_from** | Option<**String**> |  | [optional]
**network** | **String** |  | 
**memo** | Option<**String**> |  | [optional]
**txid** | Option<**String**> |  | [optional]
**block_height** | Option<**f64**> |  | [optional]
**status** | **String** |  | 
**timestamp** | **f64** |  | 
**confirmations** | **f64** |  | 
**confirmations_required** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


