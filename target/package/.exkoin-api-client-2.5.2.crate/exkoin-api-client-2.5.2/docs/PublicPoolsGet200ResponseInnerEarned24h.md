# PublicPoolsGet200ResponseInnerEarned24h

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base** | **String** |  | 
**quote** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


