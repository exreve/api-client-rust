# PublicGainsLossesTransparencyGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **f64** |  | 
**currencies** | [**std::collections::HashMap<String, models::PublicGainsLossesTransparencyGet200ResponseCurrenciesValue>**](_public_gains_losses_transparency_get_200_response_currencies_value.md) |  | 
**last_20** | [**Vec<models::PublicGainsLossesTransparencyGet200ResponseLast20Inner>**](_public_gains_losses_transparency_get_200_response_last_20_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


