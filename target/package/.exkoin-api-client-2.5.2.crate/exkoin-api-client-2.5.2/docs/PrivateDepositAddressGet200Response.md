# PrivateDepositAddressGet200Response

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**active** | Option<[**serde_json::Value**](.md)> |  | [optional]
**address** | **String** |  | 
**memo** | Option<**String**> |  | [optional]
**min_deposit_amount** | **String** |  | 
**currency_details** | [**models::PublicCurrenciesGet200ResponseInner**](_public_currencies_get_200_response_inner.md) |  | 
**network_details** | [**models::PublicNetworksGet200ResponseInner**](_public_networks_get_200_response_inner.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


