# PublicFundsTransparencyGet200ResponseFundsValueValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **f64** |  | 
**in_cold** | **f64** |  | 
**free** | **f64** |  | 
**locked** | **f64** |  | 
**address_count** | **f64** |  | 
**addresses** | **Vec<String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


