# PublicMarketsGet200ResponseInnerLimitsPrice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min** | Option<**String**> |  | [optional]
**max** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


