# PrivateOrdersPostRequest

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**symbol** | **String** |  | 
**r#type** | **String** |  | 
**side** | **String** |  | 
**quantity** | Option<**String**> |  | [optional]
**cost** | Option<**String**> |  | [optional]
**price** | Option<**String**> |  | [optional]
**client_order_id** | Option<**String**> |  | [optional]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


