# PublicExkConfigGet200ResponseUserLevelsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**points_factor** | **f64** |  | 
**name** | **String** |  | 
**description** | **String** |  | 
**icon** | **String** |  | 
**required_points** | **f64** |  | 
**benefits** | **Vec<String>** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


