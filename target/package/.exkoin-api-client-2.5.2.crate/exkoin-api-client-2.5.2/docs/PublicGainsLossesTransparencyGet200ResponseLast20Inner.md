# PublicGainsLossesTransparencyGet200ResponseLast20Inner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **String** |  | 
**network** | Option<**String**> |  | 
**amount** | **String** |  | 
**reason** | **String** |  | 
**timestamp** | **f64** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


