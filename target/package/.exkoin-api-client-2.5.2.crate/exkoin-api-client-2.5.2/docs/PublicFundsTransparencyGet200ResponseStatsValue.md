# PublicFundsTransparencyGet200ResponseStatsValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **f64** |  | 
**in_cold** | **f64** |  | 
**total_user_owned** | **f64** |  | 
**reserve** | **String** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


